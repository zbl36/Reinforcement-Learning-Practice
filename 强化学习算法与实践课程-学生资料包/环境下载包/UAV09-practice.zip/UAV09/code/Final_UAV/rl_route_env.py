"""Course-only finite-horizon waypoint MDP and inference adapter (NumPy only).
A grid cell denotes a closed obstacle box. Budget exhaustion is terminal failure.
This supplies transitions, not FQL/MAPPO training or a pre-trained policy.
"""
import numpy as np


def segment_box(a, b, lo, hi):
    lower, upper = 0., 1.
    for axis in range(2):
        d = b[axis] - a[axis]
        if abs(d) < 1e-10:
            if a[axis] < lo[axis] or a[axis] > hi[axis]:
                return False
        else:
            p, q = sorted(((lo[axis]-a[axis])/d, (hi[axis]-a[axis])/d))
            lower, upper = max(lower, p), min(upper, q)
            if lower > upper:
                return False
    return True


class WaypointEnv:
    """Absolute next-waypoint actions, one team reward per joint step.

    Single route: no segment-length constraint in the official route protocol.
    Two routes: simultaneous motion, distance >= .12, segment length <= .4.
    Public state includes the fixed map, goals, positions and remaining budget.
    An actor may use local_observations(); a centralized critic uses observation().
    """
    def __init__(self, observation):
        self.grid = np.asarray(observation['grid'], dtype=float).copy()
        self.joint = 'starts' in observation
        self.starts = np.asarray(observation['starts'] if self.joint else [observation['start']], dtype=float)
        self.goals = np.asarray(observation['goals'] if self.joint else [observation['goal']], dtype=float)
        self.n = 2 if self.joint else 1
        self.horizon = int(observation.get('horizon', 32 if self.joint else 24))
        self.min_distance = float(observation.get('min_distance', .12))
        self.max_segment = float(observation.get('max_segment_length', .4)) if self.joint else float('inf')
        if self.grid.shape != (8,8) or self.starts.shape != (self.n,2) or self.goals.shape != (self.n,2) or self.horizon < 2:
            raise ValueError('8x8 map, one/two 2D routes and horizon >=2 required')
        if not all(np.isfinite(x).all() for x in (self.grid,self.starts,self.goals)) or (np.abs(self.starts)>1).any() or (np.abs(self.goals)>1).any():
            raise ValueError('invalid map or endpoints')
        self.reset()

    def reset(self):
        self.positions = self.starts.copy()
        self.finished = np.all(np.isclose(self.positions,self.goals,atol=1e-6,rtol=0),axis=1)
        self.t = 0
        self.ended = False
        self.transitions = []
        return self.observation()

    def observation(self):
        return dict(grid=self.grid.tolist(), positions=self.positions.tolist(), goals=self.goals.tolist(),
                    remaining_steps=self.horizon-1-self.t, completed=self.finished.tolist())

    def local_observations(self, proposals=None):
        """Declared actor information: map, own goal, relative neighbor, prior proposal.
        Joint prior generation itself is centralized; do not claim fully decentralized planning.
        """
        return [dict(grid=self.grid.tolist(),position=self.positions[i].tolist(),goal=self.goals[i].tolist(),
                     neighbors=[(self.positions[j]-self.positions[i]).tolist() for j in range(self.n) if j!=i],
                     remaining_steps=self.horizon-1-self.t,completed=bool(self.finished[i]),
                     proposal=None if proposals is None else np.asarray(proposals[i]).tolist()) for i in range(self.n)]

    def step(self, action):
        if self.ended:
            raise RuntimeError('reset required after terminal transition')
        before=self.observation();old=self.positions.copy();active=(~self.finished).copy()
        a=np.asarray(action,dtype=float)
        if not self.joint and a.shape==(2,):a=a[None,:]
        if a.shape!=(self.n,2):raise ValueError('next waypoint action shape mismatch')
        # Completed agents hold position and remain physical collision obstacles.
        executed=a.copy();executed[self.finished]=old[self.finished]
        finite=bool(np.isfinite(executed).all());reason=''
        if not finite:reason='nonfinite'
        elif (np.abs(executed)>1).any():reason='out_of_bounds'
        lengths=np.linalg.norm(executed-old,axis=1) if finite else np.zeros(self.n)
        if finite and not reason and (lengths>self.max_segment+1e-9).any():reason='step_length'
        if finite and not reason:
            for r,c in np.argwhere(self.grid>0):
                lo=np.array([c,r])/4-1
                if any(segment_box(x,y,lo,lo+.25) for x,y in zip(old,executed)):
                    reason='obstacle';break
        if self.joint and finite and not reason:
            relative=old[0]-old[1];velocity=(executed[0]-executed[1])-relative
            tau=np.clip(-np.dot(relative,velocity)/max(float(np.dot(velocity,velocity)),1e-12),0,1)
            if np.linalg.norm(relative+tau*velocity)<self.min_distance:reason='agent_collision'
        # Never propagate NaNs into replay; this attempted action still terminates with a penalty.
        self.positions=executed if finite else old
        self.t+=1
        self.finished |= np.all(np.isclose(self.positions,self.goals,atol=1e-6,rtol=0),axis=1)
        success=bool(self.finished.all()) and not reason
        if not success and not reason and self.t>=self.horizon-1:reason='budget_exhausted'
        progress=float(np.linalg.norm(old-self.goals,axis=1).sum()-np.linalg.norm(self.positions-self.goals,axis=1).sum())
        reward=progress-.05*float(lengths.sum())-.01-(.01 if np.all(lengths<1e-9) else 0.)
        if success:reward+=10.
        elif reason:reward-=10.
        terminated=bool(success or reason);self.ended=terminated
        after=self.observation()
        transition=dict(state=before,action=a.tolist(),executed_action=self.positions.tolist(),reward=float(reward),next_state=after,
                        terminated=terminated,truncated=False,active_mask=active.tolist(),completed=self.finished.tolist(),
                        success=success,failure_reason=reason)
        self.transitions.append(transition)
        return after,float(reward),terminated,False,transition


def rollout_paths(observation, policy):
    """Bridge a frozen one-step policy to judge act()->{'paths':[candidate]}.
    policy(state) returns one waypoint or a synchronous pair. No forced goal,
    interpolation, smoothing or planner fallback hides a failed rollout.
    """
    env=WaypointEnv(observation);trace=[env.positions.copy()]
    for _ in range(env.horizon-1):
        if not env.ended:
            env.step(policy(env.observation()))
        trace.append(env.positions.copy())
    paths=np.stack(trace,axis=1)
    if not env.joint:paths=paths[0]
    # In particular NaN actions must not accidentally become a feasible held path.
    if any(t['failure_reason']=='nonfinite' for t in env.transitions):
        paths[..., -1, :] = [2.,2.]
    return {'paths':[paths.tolist()]}
