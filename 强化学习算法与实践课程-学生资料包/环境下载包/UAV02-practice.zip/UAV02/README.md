# UAV02 · 环境包（未完成）

专家示范预训练与强化学习微调的无人机避障

提供环境与接口，不含完整训练算法、训练权重、已运行输出或成绩。`policy.py` 为待实现接口；直接提交不能视为完成。

## 运行环境检查

需要 Python 3.10 或更新版本。在本包目录执行 `python -m venv .venv`。
激活环境：macOS / Linux 用 `source .venv/bin/activate`，Windows PowerShell 用 `.venv\Scripts\Activate.ps1`。

```sh
python -m pip install -r requirements.txt
python run_example.py
```

首次安装依赖需要联网。示例只运行几步环境交互，不训练模型，也不生成成绩；通过检查后仍为“未完成”。
交互编写可用 `python -m jupyterlab code/Final_UAV/01_route_planning.ipynb`，在 Notebook 的学生区域添加代码。

## 课程要求与提交

学生可自行选文，至少精读2篇，每篇均须实际使用强化学习方法。要求见[学生手册](http://127.0.0.1:38180/research/course-project-handbook.pdf)。
平台实现选做。完成自己的训练与 `policy.py` 后，按 `protocol.json` 接口在[课程平台](http://127.0.0.1:38180/projects)提交；环境检查输出不是训练证据或复评成绩。
