# Environment-only distribution. RL training and student policy are not implemented.
"""Two-UAV joint geometric trajectory generation, a separate 8x8 fixed-altitude track.
Prioritized space-time BFS provides supervision. No task-allocation head supplied.
"""
import hashlib
import random
import time
from collections import deque
from pathlib import Path
import numpy as np
from generative_routes import SIZE, point, scene, expert, route_metrics
HORIZON = 32
MIN_DISTANCE = 0.12

def to_cell(p):
    return tuple(np.floor((p[::-1] + 1) * SIZE / 2).astype(int))

def joint_expert(s):
    first = [to_cell(p) for p in expert(s['grid'], to_cell(s['start']), to_cell(s['goal']), s['id'])]
    first += [first[-1]] * (HORIZON - len(first))
    (start, goal) = (first[-1], first[0])
    queue = deque([(start, 0)])
    parent = {(start, 0): None}
    finish = None
    while queue:
        (cell, t) = queue.popleft()
        if cell == goal and all((first[u] != goal for u in range(t, HORIZON))):
            finish = (cell, t)
            break
        if t >= HORIZON - 1:
            continue
        for (dr, dc) in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1)):
            nxt = (cell[0] + dr, cell[1] + dc)
            if not all((0 <= v < SIZE for v in nxt)) or s['grid'][nxt]:
                continue
            if nxt == first[t + 1] or (nxt == first[t] and cell == first[t + 1]):
                continue
            key = (nxt, t + 1)
            if key not in parent:
                parent[key] = (cell, t)
                queue.append(key)
    if finish is None:
        raise ValueError('joint route infeasible')
    second = []
    key = finish
    while key is not None:
        second.append(key[0])
        key = parent[key]
    second = second[::-1]
    second += [second[-1]] * (HORIZON - len(second))
    return np.array([[point(p) for p in first], [point(p) for p in second]], dtype=np.float32)

def multi_scene(index):
    s = scene(index)
    s['target'] = joint_expert(s)
    s['starts'] = s['target'][:, 0]
    s['goals'] = s['target'][:, -1]
    s['condition'] = np.r_[s['grid'].ravel(), s['starts'].ravel(), s['goals'].ravel()].astype(np.float32)
    return s

def metrics(paths, s):
    spatial = [route_metrics(path, {**s, 'goal': s['goals'][i]}) for (i, path) in enumerate(paths)]
    conflicts = 0
    minimum = float('inf')
    if np.isfinite(paths).all():
        for k in range(paths.shape[1] - 1):
            a = paths[0, k] - paths[1, k]
            v = paths[0, k + 1] - paths[1, k + 1] - a
            t = np.clip(-np.dot(a, v) / max(float(np.dot(v, v)), 1e-12), 0, 1)
            distance = float(np.linalg.norm(a + t * v))
            minimum = min(minimum, distance)
            conflicts += int(distance < MIN_DISTANCE)
    else:
        minimum = 0
        conflicts = HORIZON - 1
    max_step = float(np.max(np.linalg.norm(np.diff(paths, axis=1), axis=2))) if np.isfinite(paths).all() else None
    return dict(feasible=int(all((m['feasible'] for m in spatial)) and (not conflicts) and (max_step is not None) and (max_step <= 0.4)), collision_intervals=conflicts, min_distance=minimum, spatial_collisions=sum((m['collision_cells'] for m in spatial)), total_length=sum((m['length'] for m in spatial)) if all((m['length'] is not None for m in spatial)) else None, max_step=max_step)
