# Environment-only distribution. RL training and student policy are not implemented.
"""Planar quadrotor teaching model; not a six-DoF or aerodynamic simulator."""
import hashlib
import json
import math
import random
import statistics
from pathlib import Path
MASS = 0.027
INERTIA = 1.4e-05
DT = 0.02
GRAVITY = 9.81

class PlanarQuadrotor:
    """[x,z,vx,vz,pitch,pitch_rate], action [total_thrust, pitch_torque]."""

    def __init__(self, mass_scale=1.0, wind=0.0, seed=0):
        self.mass = MASS * mass_scale
        self.wind = wind
        self.rng = random.Random(seed)
        self.state = [0.05 * self.rng.uniform(-1, 1), 1.0 + 0.05 * self.rng.uniform(-1, 1), 0.0, 0.0, 0.0, 0.0]

    def step(self, action):
        thrust = max(0.0, min(2 * MASS * GRAVITY, float(action[0])))
        torque = max(-0.0003, min(0.0003, float(action[1])))
        (x, z, vx, vz, theta, omega) = self.state
        vx += DT * (thrust * math.sin(theta) / self.mass + self.wind)
        vz += DT * (thrust * math.cos(theta) / self.mass - GRAVITY)
        omega += DT * torque / INERTIA
        (x, z, theta) = (x + DT * vx, z + DT * vz, theta + DT * omega)
        self.state = [x, z, vx, vz, theta, omega]
        unsafe = z < 0.2 or z > 2.0 or abs(x) > 2.0 or (abs(theta) > 0.65)
        return (self.state[:], unsafe, [thrust, torque])

def target(time, task='track'):
    return [0.5 * math.sin(0.5 * time), 1.0, 0.25 * math.cos(0.5 * time), 0.0] if task == 'track' else [0.0, 1.0, 0.0, 0.0]

class PID:

    def __init__(self):
        self.integral = [0.0, 0.0]

    def act(self, state, reference):
        (x, z, vx, vz, pitch, omega) = state
        (ex, ez) = (reference[0] - x, reference[1] - z)
        self.integral = [max(-0.4, min(0.4, i + DT * e)) for (i, e) in zip(self.integral, (ex, ez))]
        ax = 4 * ex + 3 * (reference[2] - vx) + 0.5 * self.integral[0]
        az = GRAVITY + 6 * ez + 4 * (reference[3] - vz) + 2 * self.integral[1]
        desired = max(-0.4, min(0.4, math.atan2(ax, az)))
        thrust = MASS * math.hypot(ax, az)
        torque = INERTIA * (80 * (desired - pitch) - 16 * omega)
        return [thrust, torque]
