# Environment-only distribution. RL training and student policy are not implemented.
"""PID expert -> BC/DDPM/CFM short motor-command chunks -> closed-loop rollout.
Supports three canonical language task labels, not a pretrained VLM or VLA.
"""
import hashlib
import math
import random
import time
from pathlib import Path
import numpy as np
from control import PlanarQuadrotor, PID, DT, MASS, GRAVITY, target
CHUNK = 4
TASKS = ('hover', 'right', 'left')
LANGUAGE = {'悬停': 'hover', '保持当前位置': 'hover', '向右巡航': 'right', '向右飞': 'right', '向左巡航': 'left', '向左飞': 'left'}
STATE_SCALE = np.array([1, 1, 1, 1, 0.4, 2], dtype=np.float32)
ACTION_SCALE = np.array([MASS * GRAVITY, 0.0003], dtype=np.float32)
ACTION_CENTER = np.array([MASS * GRAVITY, 0], dtype=np.float32)

def parse_language(text):
    if text not in LANGUAGE:
        raise ValueError('unsupported canonical task; add parser or embeddings as student extension')
    return LANGUAGE[text]

def reference(t, task):
    if task == 'hover':
        return [0, 1, 0, 0]
    sign = 1 if task == 'right' else -1
    return [sign * 0.35 * math.sin(0.5 * t), 1, sign * 0.175 * math.cos(0.5 * t), 0]

def condition(state, ref, task, language=False, t=0.0):
    base = np.r_[np.asarray(state) / STATE_SCALE, ref].astype(np.float32)
    if language:
        base[6] = 0.0
        base[8] = 0.0
        return np.r_[base, math.sin(0.5 * t), math.cos(0.5 * t), [int(task == name) for name in TASKS]].astype(np.float32)
    return base

def expert_data(episodes=24, steps=100, language=False):
    (conditions, actions, ids) = ([], [], [])
    for episode in range(episodes):
        rng = random.Random(1000 + episode)
        task = TASKS[episode % 3] if language else 'right'
        env = PlanarQuadrotor(seed=1000 + episode)
        env.state = [rng.uniform(-0.25, 0.25), rng.uniform(0.8, 1.2), rng.uniform(-0.1, 0.1), rng.uniform(-0.1, 0.1), rng.uniform(-0.08, 0.08), 0.0]
        pid = PID()
        cs = []
        ys = []
        for k in range(steps):
            ref = reference(k * DT, task)
            cs.append(condition(env.state, ref, task, language, k * DT))
            (state, unsafe, applied) = env.step(pid.act(env.state, ref))
            ys.append((np.asarray(applied) - ACTION_CENTER) / ACTION_SCALE)
            if unsafe:
                break
        for k in range(len(ys) - CHUNK + 1):
            conditions.append(cs[k])
            actions.append(np.asarray(ys[k:k + CHUNK]).ravel())
            ids.append(1000 + episode)
    return (np.asarray(conditions), np.asarray(actions), ids)
