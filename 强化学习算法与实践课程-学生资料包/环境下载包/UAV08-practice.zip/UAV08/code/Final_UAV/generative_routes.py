# Environment-only distribution. RL training and student policy are not implemented.
"""Fixed-altitude geometric route generation on held-out 8x8 scenes.
No rigid-body dynamics, battery or tracking claims. Collision test is segment/AABB.
"""
import hashlib
import itertools
import random
import time
from collections import deque
from pathlib import Path
import numpy as np
SIZE = 8
HORIZON = 24

def point(cell):
    return np.array([(cell[1] + 0.5) / SIZE * 2 - 1, (cell[0] + 0.5) / SIZE * 2 - 1], dtype=np.float32)

def expert(grid, start, goal, seed=0):
    rng = random.Random(seed)
    queue = deque([start])
    parents = {start: None}
    while queue:
        cell = queue.popleft()
        if cell == goal:
            break
        neighbors = [(cell[0] + dr, cell[1] + dc) for (dr, dc) in ((1, 0), (-1, 0), (0, 1), (0, -1))]
        rng.shuffle(neighbors)
        for nxt in neighbors:
            if all((0 <= i < SIZE for i in nxt)) and (not grid[nxt]) and (nxt not in parents):
                parents[nxt] = cell
                queue.append(nxt)
    if goal not in parents:
        raise ValueError('unreachable scene')
    cells = []
    cell = goal
    while cell is not None:
        cells.append(cell)
        cell = parents[cell]
    return np.array([point(c) for c in cells[::-1]])

def resample(path, count=HORIZON):
    lengths = np.r_[0, np.cumsum(np.linalg.norm(np.diff(path, axis=0), axis=1))]
    if lengths[-1] == 0:
        return np.repeat(path[:1], count, axis=0)
    at = np.linspace(0, lengths[-1], count)
    return np.stack([np.interp(at, lengths, path[:, axis]) for axis in range(2)], axis=1).astype(np.float32)

def scene(index):
    rng = random.Random(index)
    grid = np.zeros((SIZE, SIZE), dtype=np.float32)
    gap = rng.randrange(1, 6)
    grid[:, 3] = 1
    grid[gap:gap + 2, 3] = 0
    start = (rng.randrange(SIZE), rng.randrange(3))
    goal = (rng.randrange(SIZE), rng.randrange(5, 8))
    path = expert(grid, start, goal, index)
    condition = np.r_[grid.ravel(), point(start), point(goal)].astype(np.float32)
    return dict(id=index, grid=grid, start=point(start), goal=point(goal), condition=condition, expert=path, target=resample(path))

def dataset(count=128):
    scenes = [scene(1000 + i) for i in range(count)]
    return (np.stack([s['condition'] for s in scenes]), np.stack([s['target'][1:-1].ravel() for s in scenes]))

def intersects(a, b, lo, hi):
    (low, high) = (0.0, 1.0)
    for axis in range(2):
        d = b[axis] - a[axis]
        if abs(d) < 1e-10:
            if a[axis] < lo[axis] or a[axis] > hi[axis]:
                return False
        else:
            (p, q) = sorted(((lo[axis] - a[axis]) / d, (hi[axis] - a[axis]) / d))
            low = max(low, p)
            high = min(high, q)
            if low > high:
                return False
    return True

def route_metrics(path, s):
    finite = bool(np.isfinite(path).all())
    outside = not finite or bool((np.abs(path) > 1).any())
    collisions = 0
    if finite:
        for (r, c) in np.argwhere(s['grid'] > 0):
            lo = np.array([c, r]) / SIZE * 2 - 1
            hi = lo + 2 / SIZE
            if any((intersects(a, b, lo, hi) for (a, b) in zip(path[:-1], path[1:]))):
                collisions += 1
    length = float(np.linalg.norm(np.diff(path, axis=0), axis=1).sum()) if finite else None
    return dict(feasible=int(not outside and collisions == 0), collision_cells=collisions, out_of_bounds=int(outside), length=length, endpoint_error=float(np.linalg.norm(path[-1] - s['goal'])) if finite else None)
