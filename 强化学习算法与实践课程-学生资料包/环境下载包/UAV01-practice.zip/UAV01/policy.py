"""Student inference interface. No trained or baseline policy is supplied here."""
IMPLEMENTATION_STATUS = 'not_started'

def reset(seed, replicate):
    # Optional: load your trained parameters and reset episode memory.
    pass

def act(observation, context):
    # TODO: implement your policy, respecting protocol.json.
    raise NotImplementedError('请先实现并训练自己的策略；环境测试不代表作业完成。')
