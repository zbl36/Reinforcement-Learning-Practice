# Environment-only distribution. RL training and student policy are not implemented.
"""Course route-planning baseline. Discrete battery is not physical energy."""
import hashlib
import heapq
import json
import random
import statistics
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from shared.uav_grid import UAVConfig, UAVGrid3D

def environment():
    return UAVGrid3D(UAVConfig(n_rows=5, n_cols=5, n_alts=2, target=(4, 4, 0), start=(0, 0, 0, 15), building_height={(1, 2): 2, (2, 2): 1, (3, 2): 1}, r_step=-0.05, r_target=10.0, gamma=0.95))

def astar(env, start):
    """Shortest valid route in joint position/battery state, with known model."""

    def heuristic(s):
        return sum((abs(a - b) for (a, b) in zip(s[:3], env.cfg.target)))
    queue = [(heuristic(start), 0, start, [])]
    best = {start: 0}
    while queue:
        (_, cost, state, route) = heapq.heappop(queue)
        if cost != best[state]:
            continue
        if state[:3] == env.cfg.target:
            return route
        for action in env.actions:
            (nxt, reward, done) = env.step(state, action)
            if nxt[:3] == state[:3] or reward < -0.1:
                continue
            if done and nxt[:3] != env.cfg.target:
                continue
            if cost + 1 < best.get(nxt, float('inf')):
                best[nxt] = cost + 1
                heapq.heappush(queue, (cost + 1 + heuristic(nxt), cost + 1, nxt, route + [action]))
    return []

def starts(env):
    return [(r, c, a, 15) for r in range(5) for c in range(5) for a in range(2) if not env.is_building_at(r, c, a) and (r, c, a) != env.cfg.target]
