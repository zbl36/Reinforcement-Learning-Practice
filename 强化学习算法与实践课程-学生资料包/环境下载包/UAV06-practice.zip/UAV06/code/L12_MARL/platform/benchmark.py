# Environment-only distribution. RL training and student policy are not implemented.
"""Reproducible, dependency-free introductory multi-UAV benchmark."""
import argparse
import csv
import hashlib
import json
import random
import statistics
from pathlib import Path
ACTIONS = ((-1, 0, 0), (1, 0, 0), (0, -1, 0), (0, 1, 0), (0, 0, 0), (0, 0, 1), (0, 0, -1))
COST = (1, 1, 1, 1, 0, 2, 0)

class MultiUAVGrid:
    """Simultaneous moves; conflicts terminate the team episode.

    Local observations: own position and battery. Fixed per-agent goals.
    Delivered UAVs leave the airspace. No physical flight dynamics.
    """

    def __init__(self, reward_mode='shared'):
        if reward_mode not in ('shared', 'individual'):
            raise ValueError('unknown reward mode')
        self.reward_mode = reward_mode
        self.goals = [(2, 4, 0), (2, 0, 0)]
        self.reset()

    def reset(self):
        self.positions = [(2, 0, 0), (2, 4, 0)]
        self.battery = [16, 16]
        self.arrived = [False, False]
        self.steps = self.collisions = self.energy = 0
        self.ended = False
        return self.observe()

    def observe(self):
        return [tuple(p) + (b,) for (p, b) in zip(self.positions, self.battery)]

    def step(self, actions):
        if self.ended:
            raise RuntimeError('reset required after episode end')
        if len(actions) != 2 or any((type(a) is not int or not 0 <= a < 7 for a in actions)):
            raise ValueError('two integer actions in [0,6] required')
        old = self.positions[:]
        proposed = old[:]
        rewards = [0.0, 0.0]
        active = [i for i in range(2) if not self.arrived[i]]
        for i in active:
            a = actions[i]
            used = min(COST[a], self.battery[i])
            self.battery[i] -= used
            self.energy += used
            p = tuple((old[i][k] + ACTIONS[a][k] for k in range(3)))
            rewards[i] = -0.1 - 0.02 * used
            if not (0 <= p[0] < 5 and 0 <= p[1] < 5 and (0 <= p[2] < 2)) or p == (1, 2, 0):
                rewards[i] -= 1
            else:
                proposed[i] = p
        collision = len(active) == 2 and (proposed[0] == proposed[1] or (proposed[0] == old[1] and proposed[1] == old[0]))
        self.positions = proposed
        self.steps += 1
        failed = collision
        if collision:
            self.collisions += 1
            for i in active:
                rewards[i] -= 10
        else:
            for i in active:
                if proposed[i] == self.goals[i]:
                    self.arrived[i] = True
                    rewards[i] += 10
                elif self.battery[i] == 0:
                    failed = True
                    rewards[i] -= 10
        terminated = failed or all(self.arrived)
        truncated = self.steps >= 40 and (not terminated)
        self.ended = terminated or truncated
        team_reward = sum(rewards)
        info = dict(success=int(all(self.arrived) and (not collision)), collisions=self.collisions, steps=self.steps, energy=self.energy, team_reward=team_reward)
        learning_rewards = [team_reward] * 2 if self.reward_mode == 'shared' else rewards
        return (self.observe(), learning_rewards, terminated, truncated, info)
