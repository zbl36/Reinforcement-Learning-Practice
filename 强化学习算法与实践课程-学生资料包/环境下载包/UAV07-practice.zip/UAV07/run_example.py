from pathlib import Path
import os, json
notebook=Path(__file__).resolve().parent / 'code/Final_UAV/04_llm_missions.ipynb'
os.chdir(notebook.parent)
namespace={'__name__':'__main__'}
for cell in json.loads(notebook.read_text(encoding='utf-8'))['cells']:
    if cell['cell_type']=='code':
        exec(compile(''.join(cell['source']),str(notebook),'exec'),namespace)
